<?php
$server = "localhost";
$user = "root";
$password = "senha";
$dbname = "bdagenda";
$conexao = mysqli_connect($server, $user, $password, $dbname); // Função que conecta ao banco de dados

?>