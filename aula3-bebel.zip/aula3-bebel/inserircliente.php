<?php

if($_POST["cxnome"] != "")
{
    include_once "factory/conexao.php";
    $nome = $_POST["cxnome"];
    $email = $_POST["cxemail"];
    $sql = "insert into tbclient
    (nome, email)
    values
    ('$nome','$email')";
    $query = mysqli_query($conexao,$sql); //Essa linha vai abrir o banco de dados (pegar o conteúdo da variável $conexao) e executar o comando sql da variável $sql
    echo "Dados cadastrados com sucesso!";
}
else{
    echo "Dados não cadastrados";
}
?>